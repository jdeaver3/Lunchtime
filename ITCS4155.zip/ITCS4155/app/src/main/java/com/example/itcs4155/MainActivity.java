package com.example.itcs4155;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.itcs4155.databinding.ActivityMainBinding;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MapsFragment.MapFragmentListener, MainFragment.MainFragmentListener, BuildingsFragment.BuildingsFragmentListener, GraphFragment.GraphFragmentListener {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new MainFragment(), "MAINFRAGMENT")
                .commit();


        MainFragment mainFragment = (MainFragment) getSupportFragmentManager().findFragmentByTag("MAINFRAGMENT");

        getSupportFragmentManager().executePendingTransactions();

    }

    @Override
    public void ViewMap(int thisTime, String date, boolean averages) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, MapsFragment.newInstance(Integer.toString(thisTime), date, averages), "MAPSFRAGMENT").addToBackStack(null)
                .commit();
        Log.d("viewMapTest", "Selected date: " + date);
    }

    @Override
    public void sentToBuildingList(int time, String date, boolean averages) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, BuildingsFragment.newInstance(Integer.toString(time), date,averages), "BUILDINGSFRAGMENT").addToBackStack(null)
                .commit();
    }

    @Override
    public void viewGraph(String date, String day, boolean avg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, GraphFragment.newInstance(date, day, avg), "GRAPHFRAGMENT").addToBackStack(null)
                .commit();
    }


    @Override
    public void ViewBuilding(Building building, int thisTime) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, MapsFragment.newInstance(Integer.toString(thisTime), "Aug 14 2021", false), "MAPSFRAGMENT").addToBackStack(null)
                .commit();

        MapsFragment mapsFragment = (MapsFragment) getSupportFragmentManager().findFragmentByTag("MAPSFRAGMENT");

        mapsFragment.viewBuilding(building);
    }
}