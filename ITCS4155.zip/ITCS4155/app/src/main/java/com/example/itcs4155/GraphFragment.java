package com.example.itcs4155;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.maps.android.heatmaps.WeightedLatLng;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GraphFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GraphFragment extends Fragment {

    GraphFragment.GraphFragmentListener mListener;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    ArrayList<Integer> xPoints = new ArrayList<>();
    ArrayList<String> buildingList = new ArrayList<>();
    int time = 0;
    int timePlus30 = 30;
    int devicesAtTime = 0;

    TextView label1;
    TextView label2;
    TextView label3;

    LineGraphSeries<DataPoint> series;
    GraphView graphView;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private static final String AVG_PARAM = "averagesTrue";
    private boolean averagesTrue;

    public GraphFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GraphFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static GraphFragment newInstance(String param1, String param2, boolean averages) {
        GraphFragment fragment = new GraphFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        args.putBoolean(AVG_PARAM, averages);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_graph, container, false);
        // Inflate the layout for this fragment
        getActivity().setTitle("Graph");

        graphView = view.findViewById(R.id.graph);

        label1 = view.findViewById(R.id.label1);
        label2 = view.findViewById(R.id.label2);
        label3 = view.findViewById(R.id.label3);

        graphView.setVisibility(View.INVISIBLE);
        label1.setVisibility(View.INVISIBLE);
        label2.setVisibility(View.INVISIBLE);
        label3.setVisibility(View.INVISIBLE);

        graphView.getGridLabelRenderer().setGridColor(Color.WHITE);
        graphView.getGridLabelRenderer().setHorizontalLabelsColor(Color.WHITE);
        graphView.getGridLabelRenderer().setVerticalLabelsColor(Color.WHITE);
        graphView.getGridLabelRenderer().setHorizontalAxisTitleColor(Color.WHITE);
        graphView.getGridLabelRenderer().setVerticalAxisTitleColor(Color.WHITE);
        graphView.getGridLabelRenderer().setVerticalLabelsSecondScaleColor(Color.WHITE);

        graphView.setBackgroundColor(Color.BLACK);
        graphView.setTitleColor(Color.WHITE);

        buildingList.add("StuU");
        //buildingList.put("CHHS", CHHS);
        //buildingList.put("Cato", Cato);
        buildingList.add("Burs");
        buildingList.add("Wood");
        buildingList.add("Atki");
        buildingList.add("AtkiG");
        buildingList.add("AtkiL");
        buildingList.add("StuA");
        buildingList.add("Smit");
        buildingList.add("Came");
        buildingList.add("Pros");
        buildingList.add("McEn");
        buildingList.add("BelH");
        buildingList.add("Lync");
        buildingList.add("Kenn");
        buildingList.add("Denn");
        buildingList.add("Fret");
        buildingList.add("Rowe");
        buildingList.add("UREC");
        buildingList.add("Winn");
        buildingList.add("With");
        buildingList.add("StuH");
        buildingList.add("Wall");
        buildingList.add("CoEd");
        buildingList.add("Heal");
        buildingList.add("Cone");
        buildingList.add("King");
        buildingList.add("MilH");
        buildingList.add("Unio");
        buildingList.add("BelG");

        getData();

        FirebaseDatabase db = FirebaseDatabase.getInstance();

        series = new LineGraphSeries<>();

        return view;
    }

    interface GraphFragmentListener {
        //void ViewMap(int thisTime, String date, boolean averages);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (GraphFragment.GraphFragmentListener) context;
    }
    public void getData(){

        if(getArguments().getBoolean(AVG_PARAM) == false) {
            FirebaseDatabase db = FirebaseDatabase.getInstance();
            graphView.setTitle("Population over " + getArguments().getString(ARG_PARAM1));

            db.getReference("historical").child(getArguments().getString(ARG_PARAM1)).child(time + "-" + timePlus30).
                    get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    String json = String.valueOf(task.getResult().getValue());

                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String test = jsonObject.getString("buildings");
                        JSONObject jsonBuilding = new JSONObject(test);
                        devicesAtTime = 0;

                        for (int i = 0; i < buildingList.size(); i++) {
                            if (jsonBuilding.has(buildingList.get(i))) {
                                android.util.Log.d("testing", buildingList.get(i));
                                String buildingName = jsonBuilding.getString(buildingList.get(i));
                                JSONObject jsonCount = new JSONObject(buildingName);
                                int buildingCount = jsonCount.getInt("device_count");
                                android.util.Log.d("graph_Testing", "Building: " + buildingName + " Count: " + buildingCount);
                                devicesAtTime = devicesAtTime + buildingCount;
                            }
                        }

                        android.util.Log.d("graph_Testing", "Total ELSE: " + devicesAtTime + " / " + time);
                        series.appendData(new DataPoint(time, devicesAtTime), true, 1440);


                        time = time + 30;
                        timePlus30 = timePlus30 + 30;
                        if (time < 1410) {
                            getData();
                        } else {

                            graphView.setVisibility(View.VISIBLE);
                            label1.setVisibility(View.VISIBLE);
                            label2.setVisibility(View.VISIBLE);
                            label3.setVisibility(View.VISIBLE);

                            graphView.addSeries(series);


                            graphView.getViewport().setYAxisBoundsManual(true);
                            graphView.getViewport().setXAxisBoundsManual(true);


                            graphView.getViewport().setMaxX(1440);
                            graphView.getViewport().setMinX(0);


                            graphView.getGridLabelRenderer().setHorizontalAxisTitle("Time");
                            graphView.getGridLabelRenderer().setVerticalAxisTitle("Population");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        android.util.Log.d("graph_Testing", "Error " + e.toString());
                    }
                }
            });
        } else {
            FirebaseDatabase db = FirebaseDatabase.getInstance();
            graphView.setTitle("Average Population over " + getArguments().getString(ARG_PARAM2));

            db.getReference("weekdays").child(getArguments().getString(ARG_PARAM2)).child("average").child(time + "-" + timePlus30).
                    get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    String json = String.valueOf(task.getResult().getValue());

                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String test = jsonObject.getString("buildings");
                        JSONObject jsonBuilding = new JSONObject(test);
                        devicesAtTime = 0;

                        for (int i = 0; i < buildingList.size(); i++) {
                            if (jsonBuilding.has(buildingList.get(i))) {
                                android.util.Log.d("testing", buildingList.get(i));
                                String buildingName = jsonBuilding.getString(buildingList.get(i));
                                JSONObject jsonCount = new JSONObject(buildingName);
                                int buildingCount = jsonCount.getInt("device_count");
                                android.util.Log.d("graph_Testing", "Building: " + buildingName + " Count: " + buildingCount);
                                devicesAtTime = devicesAtTime + buildingCount;
                            }
                        }

                        android.util.Log.d("graph_Testing", "Total ELSE: " + devicesAtTime + " / " + time);
                        series.appendData(new DataPoint(time, devicesAtTime), true, 1440);


                        time = time + 30;
                        timePlus30 = timePlus30 + 30;
                        if (time < 1410) {
                            getData();
                        } else {

                            graphView.setVisibility(View.VISIBLE);
                            label1.setVisibility(View.VISIBLE);
                            label2.setVisibility(View.VISIBLE);
                            label3.setVisibility(View.VISIBLE);

                            graphView.addSeries(series);


                            graphView.getViewport().setYAxisBoundsManual(true);
                            graphView.getViewport().setXAxisBoundsManual(true);


                            graphView.getViewport().setMaxX(1440);
                            graphView.getViewport().setMinX(0);


                            graphView.getGridLabelRenderer().setHorizontalAxisTitle("Time");
                            graphView.getGridLabelRenderer().setVerticalAxisTitle("Population");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        android.util.Log.d("graph_Testing", "Error " + e.toString());
                    }
                }
            });
        }
        String[] horizontalLabels = {"",""};

        StaticLabelsFormatter staticLabelsFormatter = new StaticLabelsFormatter(graphView);
        staticLabelsFormatter.setHorizontalLabels(horizontalLabels);

        graphView.getGridLabelRenderer().setLabelFormatter(staticLabelsFormatter);
        graphView.getGridLabelRenderer().setNumHorizontalLabels(2);
    }
}