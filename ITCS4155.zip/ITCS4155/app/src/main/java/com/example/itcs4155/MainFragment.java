package com.example.itcs4155;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Array;
import java.sql.Time;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MainFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MainFragment extends Fragment {

    MainFragment.MainFragmentListener mListener;
    Button viewMapButton;
    SeekBar timeBar;
    int time;
    TextView timeText;
    Spinner dateSelect;
    String selectedDate;
    Button viewAveragesButton;
    ArrayAdapter<String> adapter;
    FirebaseAuth mAuth;

    int counter = 0;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    ArrayList<String> datesList = new ArrayList<>();

    public MainFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MainFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    int total = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        mAuth = FirebaseAuth.getInstance();

        viewMapButton = view.findViewById(R.id.mapButton);
        timeText = view.findViewById(R.id.timeText);
        timeBar = view.findViewById(R.id.timeBar);
        dateSelect = view.findViewById(R.id.spinner);
        viewAveragesButton = view.findViewById(R.id.viewAveragesButton);

        viewAveragesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datesList.clear();
                mListener.ViewMap(time, selectedDate, true);
            }
        });

        FirebaseDatabase db = FirebaseDatabase.getInstance();

        db.getReference().child("historical").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                total = (int)snapshot.getChildrenCount();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        counter=0;
        db.getReference().child("historical").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                //Log.d("testing_dates", snapshot.getKey());
                datesList.add(snapshot.getKey());
                counter++;

                if(counter >= total){
                    updateSelectorBox(datesList);
                } else {
                    counter++;
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        getActivity().setTitle("Lunchtime");

        timeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                time = Integer.valueOf(i * 30);
                Double temp  = Double.valueOf(i);
                temp = temp / 2;
                String formattedTime = Double.toString(temp);
                formattedTime = formattedTime.replace(".5", ":30");
                formattedTime= formattedTime.replace(".0", ":00");
                timeText.setText(formattedTime);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        viewMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datesList.clear();
                mListener.ViewMap(time,selectedDate, false);
            }
        });
        return view;
    }

    void updateSelectorBox(ArrayList<String> list){

        String[] dateArray = new String[list.size()];
        list.toArray(dateArray);

        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, dateArray);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        dateSelect.setAdapter(adapter);


        dateSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedDate = dateSelect.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    interface MainFragmentListener {
        void ViewMap(int thisTime, String date, boolean averages);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (MainFragment.MainFragmentListener) context;
    }
}