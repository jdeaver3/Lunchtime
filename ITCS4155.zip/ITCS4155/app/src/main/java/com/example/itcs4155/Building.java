package com.example.itcs4155;

import com.google.android.gms.maps.model.LatLng;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;

public class Building {

    String building;
    String buildingAbb;
    int count;
    LatLng coord;
    String restaurants = "";

    public Building() {
    }

    public Building(String building, int count) {
        this.building = building;
        this.count = count;

    }

    public String getBuildingAbb() {
        return buildingAbb;
    }

    public void setBuildingAbb(String buildingAbb) {
        this.buildingAbb = buildingAbb;
    }

    public Building(String building, String buildingAbb, int count) {
        this.building = building;
        this.buildingAbb = buildingAbb;
        this.count = count;
    }

    public Building(String building, String buildingAbb, int count, LatLng coord) {
        this.building = building;
        this.buildingAbb = buildingAbb;
        this.count = count;
        this.coord = coord;
    }

    public String getRestaurants() {
        return restaurants;
    }

    public void setRestaurants(String restaurants) {
        this.restaurants = restaurants;
    }

    public LatLng getCoord() {
        return coord;
    }

    public void setCoord(LatLng coord) {
        this.coord = coord;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
