package com.example.itcs4155;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BuildingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BuildingsFragment extends Fragment {

    BuildingsFragment.BuildingsFragmentListener mListener;
    LinearLayoutManager layoutManager;
    BuildingRecyclerViewAdapter adapter;
    RecyclerView recyclerView;
    SeekBar seekBarBuildings;
    TextView realTimeTextBuilding;
    int time;
    String formattedTime;
    TextView dateText;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String AVG_PARAM = "averagesTrue";
    private boolean averagesTrue;

    private String mParam1;
    private String mParam2;

    ArrayList<Building> buildingsList = new ArrayList<>();

    /*
    LatLng StuU = new LatLng(35.3087104314179, -80.73365123632387);
    //LatLng CHHS = new LatLng(35.30756348375374, -80.73329182032066);
    //LatLng Cato = new LatLng(35.30759412761138, -80.73410721184464);
    LatLng Burs = new LatLng(35.30755910606354, -80.73244424227495);

    //CCI
    LatLng Wood = new LatLng(35.30716767618556, -80.73576842052182);
    LatLng Atki = new LatLng(35.30589341576858, -80.73257347843631);

    //Activity Center
    LatLng StuA = new LatLng(35.306280452164565, -80.73431418742832);
    LatLng Smit = new LatLng(35.306992110148215, -80.73155400091977);
    //LatLng CameronHall = new LatLng(35.307693869095, -80.73121750587975);
    LatLng Pros = new LatLng(35.3067940652266, -80.73089930961675);
    LatLng McEn = new LatLng(35.3072705146621, -80.73020082405739);
    //LatLng Belk = new LatLng(35.30639012128625, -80.72995066228566);
    LatLng Lync = new LatLng(35.31017187294723, -80.73376643049725);
    LatLng Kenn = new LatLng(35.30602860432403, -80.73092525084682);
    LatLng Denn = new LatLng(35.30540764200015, -80.72980994628684);
    LatLng Fret = new LatLng(35.30608389525156, -80.72913242482721);
    LatLng Rowe = new LatLng(35.304659078339036, -80.730758476332);
    LatLng UREC = new LatLng(35.308328600550674, -80.7353076677269);
    LatLng Winn = new LatLng(35.30504785132989, -80.73037494174432);
    LatLng With = new LatLng(35.31091277387275, -80.73229114295809);
    LatLng StuH = new LatLng(35.3105321204093, -80.72958612646285);
    LatLng Wall = new LatLng(35.31151067000151, -80.73376853352237);
    LatLng CoEd = new LatLng(35.30759810020295, -80.73406104060027);*/

    public BuildingsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BuildingsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static BuildingsFragment newInstance(String param1, String param2, boolean averages) {
        BuildingsFragment fragment = new BuildingsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        args.putBoolean(AVG_PARAM, averages);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_buildings, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        seekBarBuildings = view.findViewById(R.id.realTimeBarBuildings);
        realTimeTextBuilding = view.findViewById(R.id.realTimeTextBuildings);
        dateText = view.findViewById(R.id.dateText);

        dateText.setText(getArguments().getString(ARG_PARAM2));

        getActivity().setTitle("Buildings");


        LatLng StuU = new LatLng(35.3087104314179, -80.73365123632387);
        Building StudentUnion = new Building("Student Union", "StuU", 0 , StuU);
        StudentUnion.setRestaurants("Wendy's, Bojangles, Starbucks, Crown Commons, Shake Smart");
        buildingsList.add(StudentUnion);

        LatLng Pros = new LatLng(35.3067940652266, -80.73089930961675);
        Building Prospector = new Building("Prospector", "Pros", 0 , Pros);
        Prospector.setRestaurants("Chick-fil-a, Salsarita's, Sushi with Gusto, Bojangles Express");
        buildingsList.add(Prospector);

        LatLng Cone = new LatLng(35.305377103478996, -80.73320829283401);
        Building ConeH = new Building("Cone", "Cone", 0, Cone);
        ConeH.setRestaurants("Panda Express, Subway");
        buildingsList.add(ConeH);

        LatLng Atki = new LatLng(35.30589341576858, -80.73257347843631);
        Building Atkins = new Building("Atkins", "Atki", 0 , Atki);
        Atkins.setRestaurants("Peet's Coffee");
        buildingsList.add(Atkins);

        LatLng Burs = new LatLng(35.30755910606354, -80.73244424227495);
        Building Burson = new Building("Burson", "Burs", 0 , Burs);
        buildingsList.add(Burson);

        LatLng Wood = new LatLng(35.30716767618556, -80.73576842052182);
        Building Woodward = new Building("Woodward", "Wood", 0 , Wood);
        buildingsList.add(Woodward);

        LatLng StuA = new LatLng(35.306280452164565, -80.73431418742832);
        Building StudentActivity = new Building("Student Activity Center", "StuA", 0 , StuA);
        buildingsList.add(StudentActivity);


        LatLng Smit = new LatLng(35.306992110148215, -80.73155400091977);
        Building SmithHall = new Building("Smith Hall", "Smit", 0 , Smit);
        buildingsList.add(SmithHall);


        LatLng Came = new LatLng(35.307693869095, -80.73121750587975);
        Building CameronHall = new Building("Cameron Hall", "Came", 0 , Came);
        buildingsList.add(CameronHall);

        LatLng McEn = new LatLng(35.3072705146621, -80.73020082405739);
        Building McEniry  = new Building("McEniry", "McEn", 0 , McEn);
        buildingsList.add(McEniry);

        LatLng BelH = new LatLng(35.31029805177956, -80.73509745258882);
        Building BelkHall  = new Building("Belk Hall", "BelH", 0 , BelH);
        buildingsList.add(BelkHall);

        LatLng Lync = new LatLng(35.31017187294723, -80.73376643049725);
        Building LynchHall  = new Building("Lynch Hall", "Lync", 0 , Lync);
        buildingsList.add(LynchHall);

        LatLng Kenn = new LatLng(35.30602860432403, -80.73092525084682);
        Building Kennedy  = new Building("Kennedy", "Kenn", 0 , Kenn);
        buildingsList.add(Kennedy);

        LatLng Denn = new LatLng(35.30540764200015, -80.72980994628684);
        Building Denny  = new Building("Denny", "Denn", 0 , Denn);
        buildingsList.add(Denny);

        LatLng Fret = new LatLng(35.30608389525156, -80.72913242482721);
        Building Fretwell  = new Building("Fretwell", "Fret", 0 , Fret);
        buildingsList.add(Fretwell);

        LatLng Rowe = new LatLng(35.304659078339036, -80.730758476332);
        Building RoweH  = new Building("Rowe", "Rowe", 0 , Rowe);
        buildingsList.add(RoweH);

        LatLng UREC = new LatLng(35.308328600550674, -80.7353076677269);
        Building UniversityRecreation  = new Building("University Recreation", "UREC", 0 , UREC);
        buildingsList.add(UniversityRecreation);


        Building Witherspoon  = new Building("Witherspoon", "With", 0 , UREC);
        buildingsList.add(Witherspoon);

        Building StuH  = new Building("Student Health Center", "StuH", 0 , UREC);
        buildingsList.add(StuH);

        Building Wall  = new Building("Wallis Hall", "Wall", 0 , UREC);
        buildingsList.add(Wall);

        Building CoEd  = new Building("Cato College of Education", "CoEd", 0 , UREC);
        buildingsList.add(CoEd);

        Building King  = new Building("King", "King", 0 , UREC);
        buildingsList.add(King);

        Building MilH  = new Building("Miltimore Hall", "MilH", 0 , UREC);
        buildingsList.add(MilH);


        Building BelG  = new Building("Belk Gym", "BelG", 0 , UREC);
        buildingsList.add(BelG);

        LatLng Robi = new LatLng(35.308328600550674, -80.7353076677269);
        Building Robinson  = new Building("Robinson Hall", "Robi", 0 , Robi);
        buildingsList.add(Robinson);

        LatLng Colv = new LatLng(35.308328600550674, -80.7353076677269);
        Building Colvard  = new Building("Colvard", "Colv", 0 , Colv);
        buildingsList.add(Colvard);

        LatLng Rees = new LatLng(35.308328600550674, -80.7353076677269);
        Building Reese  = new Building("Reese", "Rees", 0 , Rees);
        buildingsList.add(Reese);

        LatLng Frid = new LatLng(35.308328600550674, -80.7353076677269);
        Building Friday  = new Building("Belk College of Business", "Frid", 0 , Frid);
        buildingsList.add(Friday);

        LatLng Auxi = new LatLng(35.308328600550674, -80.7353076677269);
        Building Auxiliary  = new Building("Auxiliary Services Building", "Auxi", 0 , Auxi);
        buildingsList.add(Auxiliary);

        LatLng Epic = new LatLng(35.308328600550674, -80.7353076677269);
        Building EPIC  = new Building("Epic", "Epic", 0 , Epic);
        buildingsList.add(EPIC);

        LatLng EpicG = new LatLng(35.308328600550674, -80.7353076677269);
        Building EPICG  = new Building("Epic Ground", "EpicG", 0 , EpicG);
        buildingsList.add(Auxiliary);

        Building Grig  = new Building("Grig", "Grig", 0 , Auxi);
        buildingsList.add(Grig);

        Building Duke  = new Building("Duke", "Duke", 0 , Auxi);
        buildingsList.add(Duke);

        Building Bioi  = new Building("BioInformatic", "Bioi", 0 , Auxi);
        buildingsList.add(Bioi);

        Building PORT  = new Building("Portal", "PORT", 0 , Auxi);
        buildingsList.add(PORT);

        Building Levi  = new Building("Levine", "Levi", 0 , Auxi);
        buildingsList.add(Levi);

        Building Laur  = new Building("Laural Hall", "Laur", 0 , Auxi);
        buildingsList.add(Laur);

        Building HunH  = new Building("Hunt Hall", "HunH", 0 , Auxi);
        buildingsList.add(HunH);

        Building Scot  = new Building("Scott Hall", "Scot", 0 , Auxi);
        buildingsList.add(Scot);

        Building Hous  = new Building("Holshouser Hall", "Hous", 0 , Auxi);
        buildingsList.add(Hous);

        Building Mart  = new Building("Martin Hall", "Mart", 0 , Auxi);
        buildingsList.add(Mart);


        //set progress and text from param
        int paramTime = Integer.valueOf(Integer.valueOf(getArguments().getString(ARG_PARAM1)));
        Double temp  = Double.valueOf(Integer.valueOf(getArguments().getString(ARG_PARAM1)));
        temp = temp / 2;
        temp = temp / 30;
        formattedTime = Double.toString(temp);
        formattedTime = formattedTime.replace(".5", ":30");
        formattedTime = formattedTime.replace(".0", ":00");
        seekBarBuildings.setProgress(paramTime / 30);
        realTimeTextBuilding.setText(formattedTime);
        adjustTime(Integer.valueOf(getArguments().getString(ARG_PARAM1)));

        seekBarBuildings.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                time = Integer.valueOf(i * 30);

                Double temp  = Double.valueOf(i);
                temp = temp / 2;
                String formattedTime = Double.toString(temp);
                formattedTime = formattedTime.replace(".5", ":30");
                formattedTime = formattedTime.replace(".0", ":00");

                realTimeTextBuilding.setText(formattedTime);
                adjustTime(time);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        return view;
    }

    interface BuildingsFragmentListener {
        void ViewBuilding(Building building, int thisTime);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (BuildingsFragment.BuildingsFragmentListener) context;
    }

    public void adjustTime(int time){
        FirebaseDatabase db = FirebaseDatabase.getInstance();

        int timePlus30 = time;
        timePlus30 = timePlus30 + 30;

        //bPcycI03D9wcebHQVEzZ
        android.util.Log.d("testingCount", time + "-" + timePlus30);

        if(getArguments().getBoolean(AVG_PARAM) == false){
            Log.d("Param Test", getArguments().getString(ARG_PARAM2));
            db.getReference("historical").child(getArguments().getString(ARG_PARAM2)).child(String.valueOf(time) + "-" + String.valueOf(time + 30)).
                    get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    String json = String.valueOf(task.getResult().getValue());
                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String test = jsonObject.getString("buildings");
                        JSONObject jsonBuilding = new JSONObject(test);
                        for(int i = 0; i < buildingsList.size(); i++){
                            if (jsonBuilding.has(buildingsList.get(i).getBuildingAbb())) {
                                String buildingName = jsonBuilding.getString(buildingsList.get(i).getBuildingAbb());
                                JSONObject jsonCount = new JSONObject(buildingName);
                                int buildingCount = jsonCount.getInt("device_count");
                                buildingsList.get(i).setCount(buildingCount);
                            }
                        }

                        recyclerView.setHasFixedSize(true);
                        layoutManager = new LinearLayoutManager(getContext());
                        recyclerView.setLayoutManager(layoutManager);
                        adapter = new BuildingRecyclerViewAdapter(buildingsList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();


                    } catch (JSONException e) {
                        e.printStackTrace();
                        android.util.Log.d("testing_error", "Error " + e.toString());
                    }
                }
            });
        } else{
            db.getReference("weekdays").child(getArguments().getString(ARG_PARAM2)).child("average").child(String.valueOf(time) + "-" + String.valueOf(time + 30)).
                    get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    String json = String.valueOf(task.getResult().getValue());
                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String test = jsonObject.getString("buildings");
                        JSONObject jsonBuilding = new JSONObject(test);
                        for(int i = 0; i < buildingsList.size(); i++){
                            if (jsonBuilding.has(buildingsList.get(i).getBuildingAbb())) {
                                String buildingName = jsonBuilding.getString(buildingsList.get(i).getBuildingAbb());
                                JSONObject jsonCount = new JSONObject(buildingName);
                                int buildingCount = jsonCount.getInt("device_count");
                                buildingsList.get(i).setCount(buildingCount);
                            }
                        }

                        recyclerView.setHasFixedSize(true);
                        layoutManager = new LinearLayoutManager(getContext());
                        recyclerView.setLayoutManager(layoutManager);
                        adapter = new BuildingRecyclerViewAdapter(buildingsList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();


                    } catch (JSONException e) {
                        e.printStackTrace();
                        android.util.Log.d("testing_error", "Error Weekdays" + e.toString());
                    }
                }
            });
        }
    }

    public class BuildingRecyclerViewAdapter extends RecyclerView.Adapter<BuildingRecyclerViewAdapter.BuildingViewHolder>{
        ArrayList<Building> buildings;
        Building building;

        public BuildingRecyclerViewAdapter(ArrayList<Building> data){
            this.buildings = data;
        }

        @NonNull
        @Override
        public BuildingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.building_row_item,parent, false);
            BuildingViewHolder buildingViewHolder = new BuildingViewHolder(view);

            return buildingViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull BuildingViewHolder holder, int position) {
            building = buildings.get(position);

            holder.buildingText.setText(building.getBuilding());
            holder.countText.setText(Integer.toString(building.getCount()));
            //if(building.getRestaurants() != ""){
                holder.restaurantText.setText(buildings.get(holder.getAdapterPosition()).getRestaurants());
            //}

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mListener.ViewBuilding(building, time);
                }
            });


            //holder.postText.setText(post.description);
            //FirebaseFirestore db = FirebaseFirestore.getInstance();
            //db.collection("users").document(post.userID).addSnapshotListener(new EventListener<DocumentSnapshot>() {
                //@Override
                //public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                    //holder.postUser.setText(value.getString("name"));
                //}
            //});
            //holder.postTitle.setText(post.title);
            //holder.dateAndTimeText.setText(post.dateAndTime.toDate().toString());

            //if(myAuth.getUid().equals(post.userID)) {
                //holder.deleteButton.setVisibility(View.VISIBLE);

            //} else{
                //holder.deleteButton.setVisibility(View.INVISIBLE);
            //}
        }

        @Override
        public int getItemCount() {
            return this.buildings.size();
        }

        public class BuildingViewHolder extends RecyclerView.ViewHolder{


            TextView buildingText;
            TextView countText;
            TextView restaurantText;
            /*TextView sortName;
            ImageButton ascendName;
            ImageButton descendName;*/


            public BuildingViewHolder(@NonNull View itemView) {
                super(itemView);


                buildingText = itemView.findViewById(R.id.buildingNameText);
                countText = itemView.findViewById(R.id.countText);
                restaurantText = itemView.findViewById(R.id.restaurantsText);
                //dateAndTimeText = itemView.findViewById(R.id.dateAndTimeText);
                //deleteButton = itemView.findViewById(R.id.deleteButton);
                //postTitle = itemView.findViewById(R.id.postTitle);
            }
        }
    }
}