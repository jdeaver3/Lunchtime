package com.example.itcs4155;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.itcs4155.databinding.ActivityMainBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.TileOverlay;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import com.google.maps.android.heatmaps.WeightedLatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Set;

public class MapsFragment extends Fragment implements OnMapReadyCallback{

    MapFragmentListener mListener;
    private GoogleMap mMap;
    private ActivityMainBinding binding;
    HeatmapTileProvider mProvider;
    HeatmapTileProvider animProvider;
    TileOverlay mOverlay;
    TileOverlay animOverlay;
    SeekBar realTimeSeekBar;
    SeekBar playbackStartBar;
    SeekBar playbackEndBar;
    ProgressBar playbackPlayBar;
    TextView realTimeText;
    Button videoPlaybackButton;
    Button nextPlaybackButton;
    Button confirmPlaybackButton;
    Button buildingsListButton;
    Button returnButton;
    TextView startText;
    TextView endText;
    TextView adjustTime;
    TextView startTimeText;
    TextView endTimeText;
    ImageButton pauseButton;
    TextView showDateText;

    FirebaseAuth mAuth;

    Handler handler = new Handler();
    boolean lock = false;

    String weekDay = "Sunday";

    //Weekday Buttons
    Button sundayButton;
    Button mondayButton;
    Button tuesdayButton;
    Button wednesdayButton;
    Button thursdayButton;
    Button fridayButton;
    Button saturdayButton;
    Button graphButton;

    int time;
    int progress;
    int startTime;
    int endTime;

    //Params
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String AVG_PARAM = "averagesTrue";
    private String mParam1;
    private String mParam2;
    private boolean averagesTrue;

    public static MapsFragment newInstance(String param1, String param2, boolean averages) {
        MapsFragment fragment = new MapsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        args.putBoolean(AVG_PARAM, averages);
        fragment.setArguments(args);
        return fragment;
    }

    //ArrayList<LatLng> buildingList = new ArrayList<>();
    Map<String, LatLng> buildingList = new HashMap<>();
    LatLng StuU = new LatLng(35.3087104314179, -80.73365123632387);
    //LatLng CHHS = new LatLng(35.30756348375374, -80.73329182032066);
    //LatLng Cato = new LatLng(35.30759412761138, -80.73410721184464);
    LatLng Burs = new LatLng(35.30755910606354, -80.73244424227495);

    //CCI
    LatLng Wood = new LatLng(35.30716767618556, -80.73576842052182);
    LatLng Atki = new LatLng(35.30589341576858, -80.73257347843631);

    //Activity Center
    LatLng StuA = new LatLng(35.306280452164565, -80.73431418742832);
    LatLng Smit = new LatLng(35.306992110148215, -80.73155400091977);
    LatLng Came = new LatLng(35.307693869095, -80.73121750587975);
    LatLng Pros = new LatLng(35.3067940652266, -80.73089930961675);
    LatLng McEn = new LatLng(35.3072705146621, -80.73020082405739);
    LatLng BelH = new LatLng(35.31029805177956, -80.73509745258882);
    LatLng Lync = new LatLng(35.31017187294723, -80.73376643049725);
    LatLng Kenn = new LatLng(35.30602860432403, -80.73092525084682);
    LatLng Denn = new LatLng(35.30540764200015, -80.72980994628684);
    LatLng Fret = new LatLng(35.30608389525156, -80.72913242482721);
    LatLng Rowe = new LatLng(35.304659078339036, -80.730758476332);
    LatLng UREC = new LatLng(35.308328600550674, -80.7353076677269);
    LatLng Winn = new LatLng(35.30504785132989, -80.73037494174432);
    LatLng With = new LatLng(35.31091277387275, -80.73229114295809);
    LatLng StuH = new LatLng(35.3105321204093, -80.72958612646285);
    LatLng Wall = new LatLng(35.31151067000151, -80.73376853352237);
    LatLng CoEd = new LatLng(35.30759810020295, -80.73406104060027);
    LatLng Heal = new LatLng(35.3075104802821, -80.73336185991758);
    LatLng Cone = new LatLng(35.305377103478996, -80.73320829283401);
    LatLng King = new LatLng(35.30508333312681, -80.73255456736528);
    LatLng MilH = new LatLng(35.311479911257756, -80.73515363694497);
    LatLng Unio = new LatLng(35.30914164668188, -80.73502254011953);
    LatLng BelG = new LatLng(35.30536156402816, -80.73545952956982);

    LatLng Robi = new LatLng(35.303783048311494, -80.7299509369647);
    LatLng Colv = new LatLng(35.30482365582854, -80.73179885504156);
    LatLng Rees = new LatLng(35.30466526942099, -80.73253575122577);
    LatLng Frid = new LatLng(35.30630200512235, -80.72993951537404);
    LatLng Auxi = new LatLng(35.3077154387311, -80.73049310062585);
    LatLng EPIC = new LatLng(35.30909526291226, -80.74158781802105);
    LatLng EPICG = new LatLng(35.30909526291226, -80.74158781802105);
    LatLng Grig = new LatLng(35.31124928245903, -80.74186449172885);
    LatLng Duke = new LatLng(35.31191439305916, -80.74118402398123);
    LatLng Bioi = new LatLng(35.31264051672533, -80.74202900041678);
    LatLng BioiVEST = new LatLng(35.31264051672533, -80.74202900041678);
    LatLng PORT = new LatLng(35.31163370486375, -80.74300109719906);
    LatLng Levi = new LatLng(35.303013387774776, -80.7329168858302);
    LatLng Laur =new LatLng(35.30266185148258, -80.73611939434664);
    LatLng HunH = new LatLng(35.301388156472996, -80.73636285990638);
    LatLng Scot = new LatLng(35.301734603500634, -80.73536402684081);
    LatLng Hous = new LatLng(35.302137091567175, -80.7360819381067);
    LatLng Mart = new LatLng(35.31002995224205, -80.72744091698503);


    ArrayList<Building> logList = new ArrayList<>();
    ArrayList<WeightedLatLng> coordList = new ArrayList<>();
    String data;

        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        @Override
        public void onMapReady(GoogleMap googleMap) {
            mMap = googleMap;

            time = Integer.valueOf(getArguments().getString(ARG_PARAM1));

            // Add a marker in Sydney and move the camera
            LatLng uncc = new LatLng( 35.30842974274289, -80.73370487859805);
            //mMap.addMarker(new MarkerOptions().position(uncc).title("UNCC")).showInfoWindow();

            googleMap.setMinZoomPreference(16.0f);
            googleMap.setMaxZoomPreference(16.7f);

            // Restrict camera movement
            LatLngBounds unccBounds = new LatLngBounds(
                    new LatLng(35.30156586138344, -80.74149309126285), // SW bounds
                    new LatLng(35.31315133650628, -80.72910259465576)  // NE bounds
            );

            googleMap.setLatLngBoundsForCameraTarget(unccBounds);

            float zoomLevel = 16f; //This goes up to 21
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(uncc, zoomLevel));
            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

            List<LatLng> list = new ArrayList<>();


            FirebaseDatabase db = FirebaseDatabase.getInstance();

            int timePlus30 = Integer.valueOf(getArguments().getString(ARG_PARAM1 ));
            timePlus30 = timePlus30 + 30;

            //bPcycI03D9wcebHQVEzZ
            android.util.Log.d("testing", getArguments().getString(ARG_PARAM1) + "-" + timePlus30);


            if(getArguments().getBoolean(AVG_PARAM) == true){
                //adjustTime.setVisibility(View.INVISIBLE);
                //videoPlaybackButton.setVisibility(View.INVISIBLE);

                //Average View

                db.getReference("weekdays").child("Friday").child("average").child(getArguments().getString(ARG_PARAM1) + "-" + timePlus30).
                        get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        String json = String.valueOf(task.getResult().getValue());
                        android.util.Log.d("testing_error", "Task: " + json);
                        try {
                            JSONObject jsonObject = new JSONObject(json);
                            String test = jsonObject.getString("buildings");
                            JSONObject jsonBuilding = new JSONObject(test);
                            android.util.Log.d("Coord", "THIS IS WORKING ");


                            for (Map.Entry<String, LatLng> entry : buildingList.entrySet()) {
                                if (json.contains(entry.getKey())) {
                                    android.util.Log.d("testing", entry.getKey());
                                    String buildingName = jsonBuilding.getString(entry.getKey());
                                    JSONObject jsonCount = new JSONObject(buildingName);
                                    int buildingCount = jsonCount.getInt("device_count");
                                    android.util.Log.d("testing", "Building: " + buildingName + " Count: " + buildingCount);
                                    WeightedLatLng buildingCoord = new WeightedLatLng(buildingList.get(entry.getKey()), buildingCount);
                                    coordList.add(buildingCoord);
                                }
                            }

                            if (mProvider == null) {
                                mProvider = new HeatmapTileProvider.Builder().weightedData(coordList).maxIntensity(700).opacity(0.75).build();
                                mProvider.setRadius(125);
                                mOverlay = googleMap.addTileOverlay(new TileOverlayOptions()
                                        .tileProvider(mProvider));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            android.util.Log.d("testing_error", "Error " + e.toString());
                            android.util.Log.d("Coord", "THIS IS WORKING NOW");
                        }
                    }
                });

            } else {


                playbackPlayBar.setVisibility(View.INVISIBLE);
                sundayButton.setVisibility(View.INVISIBLE);
                mondayButton.setVisibility(View.INVISIBLE);
                tuesdayButton.setVisibility(View.INVISIBLE);
                wednesdayButton.setVisibility(View.INVISIBLE);
                thursdayButton.setVisibility(View.INVISIBLE);
                fridayButton.setVisibility(View.INVISIBLE);
                saturdayButton.setVisibility(View.INVISIBLE);

                //Historical View

                showDateText.setText(getArguments().getString(ARG_PARAM2));

                db.getReference("historical").child(getArguments().getString(ARG_PARAM2)).child(getArguments().getString(ARG_PARAM1) + "-" + timePlus30).
                        get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        String json = String.valueOf(task.getResult().getValue());
                        android.util.Log.d("testing_error", "Task: " + json);
                        try {
                            JSONObject jsonObject = new JSONObject(json);
                            String test = jsonObject.getString("buildings");
                            JSONObject jsonBuilding = new JSONObject(test);
                            android.util.Log.d("Coord", "THIS IS WORKING ");


                            for (Map.Entry<String, LatLng> entry : buildingList.entrySet()) {
                                if (json.contains(entry.getKey())) {
                                    android.util.Log.d("testing", entry.getKey());
                                    String buildingName = jsonBuilding.getString(entry.getKey());
                                    JSONObject jsonCount = new JSONObject(buildingName);
                                    int buildingCount = jsonCount.getInt("device_count");
                                    android.util.Log.d("testing", "Building: " + buildingName + " Count: " + buildingCount);
                                    WeightedLatLng buildingCoord = new WeightedLatLng(buildingList.get(entry.getKey()), buildingCount);
                                    coordList.add(buildingCoord);
                                }
                            }

                            if (mProvider == null) {
                                mProvider = new HeatmapTileProvider.Builder().weightedData(coordList).maxIntensity(700).opacity(0.75).build();
                                mProvider.setRadius(125);
                                mOverlay = googleMap.addTileOverlay(new TileOverlayOptions()
                                        .tileProvider(mProvider));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            android.util.Log.d("testing_error", "Error " + e.toString());
                            android.util.Log.d("Coord", "THIS IS WORKING NOW");
                        }
                    }
                });
            }
        }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

            View view  = inflater.inflate(R.layout.fragment_maps, container, false);

            getActivity().setTitle("Map");

            //mAuth = FirebaseAuth.getInstance();

            //mAuth.signInWithEmailAndPassword("Lunchtime@Lunchtime.com", "Lunchtime");

            //Log.d("User_Test", mAuth.getUid());

            realTimeSeekBar = view.findViewById(R.id.realTimeBar);
            realTimeText = view.findViewById(R.id.realTimeText);

            videoPlaybackButton = view.findViewById(R.id.videoPlaybackButton);
            nextPlaybackButton = view.findViewById(R.id.nextPlaybackButton);
            confirmPlaybackButton = view.findViewById(R.id.confirmPlaybackButton);
            buildingsListButton = view.findViewById(R.id.buildingListButton);

            playbackStartBar = view.findViewById(R.id.playbackStartBar);
            playbackEndBar = view.findViewById(R.id.playbackEndBar);
            startText = view.findViewById(R.id.startText);
            endText = view.findViewById(R.id.endText);
            adjustTime = view.findViewById(R.id.adjustTimeText);
            playbackPlayBar = view.findViewById(R.id.progressBar);
            startTimeText = view.findViewById(R.id.startTimeText);
            endTimeText = view.findViewById(R.id.endTimeText);
            returnButton = view.findViewById(R.id.returnButton);

            //Weekday Buttons
            sundayButton = view.findViewById(R.id.sundayButton);
            mondayButton = view.findViewById(R.id.mondayButton);
            tuesdayButton = view.findViewById(R.id.tuesdayButton);
            wednesdayButton = view.findViewById(R.id.wednesdayButton);
            thursdayButton = view.findViewById(R.id.thursdayButton);
            fridayButton = view.findViewById(R.id.fridayButton);
            saturdayButton = view.findViewById(R.id.saturdayButton);
            showDateText = view.findViewById(R.id.showDateText);

            //set progress and text from param
            int paramTime = Integer.valueOf(Integer.valueOf(getArguments().getString(ARG_PARAM1)));
            Double temp  = Double.valueOf(Integer.valueOf(getArguments().getString(ARG_PARAM1)));
            temp = temp / 2;
            temp = temp / 30;
            String formattedTime = Double.toString(temp);
            formattedTime = formattedTime.replace(".5", ":30");
            formattedTime = formattedTime.replace(".0", ":00");
            realTimeSeekBar.setProgress(paramTime / 30);
            realTimeText.setText(formattedTime);

        graphButton = view.findViewById(R.id.graphButton);

        graphButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.viewGraph(getArguments().getString(ARG_PARAM2), weekDay, getArguments().getBoolean(AVG_PARAM));
            }
        });

            sundayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Sunday";
                    SetHeatMap(time, mProvider, true);

                }
            });

            mondayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Monday";
                    SetHeatMap(time, mProvider, true);
                }
            });

            tuesdayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Tuesday";
                    SetHeatMap(time, mProvider, true);
                }
            });

            wednesdayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Wednesday";
                    SetHeatMap(time, mProvider, true);
                }
            });

            thursdayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Thursday";
                    SetHeatMap(time, mProvider, true);
                }
            });

            fridayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Friday";
                    SetHeatMap(time, mProvider, true);
                }
            });

            saturdayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    weekDay = "Saturday";
                    SetHeatMap(time, mProvider, true);
                }
            });


            videoPlaybackButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //Unhide start seek bar
                    startText.setVisibility(View.VISIBLE);
                    playbackStartBar.setVisibility(View.VISIBLE);
                    videoPlaybackButton.setVisibility(View.INVISIBLE);
                    nextPlaybackButton.setVisibility(View.VISIBLE);
                    realTimeSeekBar.setVisibility(View.INVISIBLE);
                    adjustTime.setVisibility(View.INVISIBLE);
                    playbackStartBar.setProgress(time / 30);

                    playbackStartBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                            time = Integer.valueOf(i * 30);

                            Double temp  = Double.valueOf(i);
                            temp = temp / 2;
                            String formattedTime = Double.toString(temp);
                            formattedTime = formattedTime.replace(".5", ":30");
                            formattedTime = formattedTime.replace(".0", ":00");

                            realTimeText.setText(formattedTime);
                            SetHeatMap(time, mProvider, true);

                            nextPlaybackButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    startTime = time;
                                    startText.setVisibility(View.INVISIBLE);
                                    nextPlaybackButton.setVisibility(View.INVISIBLE);
                                    confirmPlaybackButton.setVisibility(View.VISIBLE);
                                    endText.setVisibility(View.VISIBLE);
                                }
                            });



                            confirmPlaybackButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    endTime = time;
                                    time = startTime;
                                    android.util.Log.d("timeTesting", "Start Time: " + Integer.toString(startTime));
                                    android.util.Log.d("timeTesting", "End Time: " + Integer.toString(endTime));
                                    endText.setVisibility(View.INVISIBLE);
                                    adjustTime.setVisibility(View.VISIBLE);
                                    playbackStartBar.setVisibility(View.INVISIBLE);
                                    playbackPlayBar.setVisibility(View.VISIBLE);
                                    startTimeText.setVisibility(View.VISIBLE);
                                    endTimeText.setVisibility(View.VISIBLE);
                                    confirmPlaybackButton.setVisibility(View.INVISIBLE);
                                    returnButton.setVisibility(View.VISIBLE);

                                    adjustTime.setText("Time");

                                    Double temp  = Double.valueOf(startTime / 30);
                                    temp = temp / 2;
                                    String formattedTime = Double.toString(temp);
                                    formattedTime = formattedTime.replace(".5", ":30");
                                    formattedTime = formattedTime.replace(".0", ":00");

                                    startTimeText.setText(formattedTime);

                                    temp  = Double.valueOf(endTime / 30);
                                    temp = temp / 2;
                                    formattedTime = Double.toString(temp);
                                    formattedTime = formattedTime.replace(".5", ":30");
                                    formattedTime = formattedTime.replace(".0", ":00");

                                    endTimeText.setText(formattedTime);

                                    playbackPlayBar.setMax((endTime / 30) - (startTime / 30));
                                    android.util.Log.d("timeTesting", Integer.toString((endTime / 30) - (startTime / 30)));
                                    progress = 0;



                                        handler = new Handler();
                                        Runnable runnable = new Runnable() {
                                            @Override
                                            public void run() {
                                                // do something
                                                if(time < endTime) {
                                                    lock = true;
                                                    progress++;
                                                    time = time + 30;
                                                    SetHeatMap(time, mProvider, true);
                                                    playbackPlayBar.setProgress(progress);
                                                    //delayedRemove();

                                                    Double temp  = Double.valueOf(time / 30);
                                                    temp = temp / 2;
                                                    String formattedTime = Double.toString(temp);
                                                    formattedTime = formattedTime.replace(".5", ":30");
                                                    formattedTime = formattedTime.replace(".0", ":00");

                                                    realTimeText.setText(formattedTime);

                                                    handler.postDelayed(this, 1000L);  // 1 second delay
                                                } else{
                                                    handler.removeCallbacksAndMessages(null);
                                                }
                                            }
                                        };

                                    Runnable stopTask = new Runnable() {
                                        @Override
                                        public void run() {
                                            lock = false;
                                        }
                                    };
                                        handler.post(runnable);
                                    }

                            });


                            returnButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    adjustTime.setVisibility(View.VISIBLE);
                                    playbackStartBar.setVisibility(View.INVISIBLE);
                                    playbackPlayBar.setVisibility(View.INVISIBLE);
                                    startTimeText.setVisibility(View.INVISIBLE);
                                    endTimeText.setVisibility(View.INVISIBLE);
                                    confirmPlaybackButton.setVisibility(View.INVISIBLE);
                                    returnButton.setVisibility(View.INVISIBLE);
                                    realTimeSeekBar.setVisibility(View.VISIBLE);
                                    videoPlaybackButton.setVisibility(View.VISIBLE);
                                    adjustTime.setText("Adjust Time");
                                    handler.removeCallbacksAndMessages(null);

                                    realTimeSeekBar.setProgress(time / 30);
                                }
                            });
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });
                }
            });

            realTimeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    time = Integer.valueOf(i * 30);

                    Double temp  = Double.valueOf(i);
                    temp = temp / 2;
                    String formattedTime = Double.toString(temp);
                    formattedTime = formattedTime.replace(".5", ":30");
                    formattedTime = formattedTime.replace(".0", ":00");

                    realTimeText.setText(formattedTime);
                    SetHeatMap(time, mProvider, true);

                    buildingsListButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mOverlay.remove();
                            coordList.clear();

                            if(getArguments().getBoolean(AVG_PARAM) == true){
                                mListener.sentToBuildingList(time, weekDay, true);
                            } else{
                                mListener.sentToBuildingList(time, getArguments().getString(ARG_PARAM2), false);
                            }

                            Log.d("testingTime", Integer.toString(time));
                        }
                    });
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });

            buildingList.put("StuU", StuU);
            //buildingList.put("CHHS", CHHS);
            //buildingList.put("Cato", Cato);
            buildingList.put("Burs", Burs);
            buildingList.put("Wood", Wood);
            buildingList.put("Atki", Atki);
            buildingList.put("AtkiG", Atki);
            buildingList.put("AtkiL", Atki);
            buildingList.put("StuA", StuA);
            buildingList.put("Smit", Smit);
            buildingList.put("Came", Came);
            buildingList.put("Pros", Pros);
            buildingList.put("McEn", McEn);
            buildingList.put("BelH", BelH);
            buildingList.put("Lync", Lync);
            buildingList.put("Kenn", Kenn);
            buildingList.put("Denn", Denn);
            buildingList.put("Fret", Fret);
            buildingList.put("Rowe", Rowe);
            buildingList.put("UREC", UREC);
            buildingList.put("Winn", Winn);
            buildingList.put("With", With);
            buildingList.put("StuH", StuH);
            buildingList.put("Wall", Wall);
            buildingList.put("CoEd", CoEd);
            buildingList.put("Heal", Heal);
            buildingList.put("Cone", Cone);
            buildingList.put("King", King);
            buildingList.put("MilH", MilH);
            buildingList.put("Unio", Unio);
            buildingList.put("BelG", BelG);

        buildingList.put("Robi", Robi);
        buildingList.put("Rees", Rees);
        buildingList.put("Frid", Frid);
        buildingList.put("Auxi", Auxi);
        buildingList.put("EPIC", EPIC);
        buildingList.put("EPICG", EPICG);
        buildingList.put("Grig", Grig);
        buildingList.put("Duke", Duke);
        buildingList.put("Bioi", Bioi);
        buildingList.put("BioIVEST", BioiVEST);
        buildingList.put("PORT", PORT);
        buildingList.put("Levi", Levi);
        buildingList.put("Laur", Laur);
        buildingList.put("HunH", HunH);
        buildingList.put("Scot", Scot);
        buildingList.put("Hous", Hous);
        buildingList.put("Mart", Mart);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        //(binding.getRoot());
    }

    interface MapFragmentListener {
            void sentToBuildingList(int time, String date, boolean averages);
            void viewGraph(String date, String day, boolean avg);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (MapFragmentListener) context;
    }

    public void playVideo(int time){

    }

    public void delayedRemove(){
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                // do something
                if(time < endTime) {
                    time = time + 30;
                    mOverlay.remove();
                    coordList.clear();
                    android.util.Log.d("timeTesting", Integer.toString(time));
                    handler.postDelayed(this, 1500L);  // 1 second delay
                } else{
                    handler.removeCallbacksAndMessages(null);
                }
            }
        };
        handler.post(runnable);
    }

    public void SetHeatMap(int time, HeatmapTileProvider heatmap, boolean replace){

        FirebaseDatabase db = FirebaseDatabase.getInstance();


        int timePlus30 = time;
        timePlus30 = timePlus30 + 30;

        //bPcycI03D9wcebHQVEzZ
        android.util.Log.d("testing", time + "-" + timePlus30);

        if(replace == true){
            mOverlay.remove();
            coordList.clear();
        }
        mOverlay.setFadeIn(true);

        if(getArguments().getBoolean(AVG_PARAM) == true) {

            //Averages View

            db.getReference("weekdays").child(weekDay).child("average").child(time + "-" + timePlus30).
                    get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    showDateText.setText(weekDay);

                    String json = String.valueOf(task.getResult().getValue());
                    if (replace == true) {
                        mOverlay.remove();
                        coordList.clear();
                    }

                    mOverlay.setFadeIn(true);
                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String test = jsonObject.getString("buildings");
                        JSONObject jsonBuilding = new JSONObject(test);
                        android.util.Log.d("Coord", "THIS IS WORKING ");

                        for (Map.Entry<String, LatLng> entry : buildingList.entrySet()) {
                            if (json.contains(entry.getKey())) {
                                android.util.Log.d("testing", entry.getKey());
                                String buildingName = jsonBuilding.getString(entry.getKey());
                                JSONObject jsonCount = new JSONObject(buildingName);
                                int buildingCount = jsonCount.getInt("device_count");
                                android.util.Log.d("testing", "Building: " + buildingName + " Count: " + buildingCount);
                                WeightedLatLng buildingCoord = new WeightedLatLng(buildingList.get(entry.getKey()), buildingCount);
                                coordList.add(buildingCoord);
                            }
                        }
                        //mProvider = new HeatmapTileProvider.Builder().weightedData(coordList).maxIntensity(400).opacity(0.75).build();
                        heatmap.setWeightedData(coordList);
                        heatmap.setRadius(125);
                        mOverlay = mMap.addTileOverlay(new TileOverlayOptions()
                                .tileProvider(heatmap));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        android.util.Log.d("testing_error", "Error " + e.toString());
                    }
                }
            });

        } else {

            //Historical View

            db.getReference("historical").child(getArguments().getString(ARG_PARAM2)).child(time + "-" + timePlus30).
                    get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    String json = String.valueOf(task.getResult().getValue());

                    Log.d("average_text", "Historical");

                    if (replace == true) {
                        mOverlay.remove();
                        coordList.clear();
                    }

                    mOverlay.setFadeIn(true);
                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String test = jsonObject.getString("buildings");
                        JSONObject jsonBuilding = new JSONObject(test);
                        android.util.Log.d("Coord", "THIS IS WORKING ");

                        for (Map.Entry<String, LatLng> entry : buildingList.entrySet()) {
                            if (json.contains(entry.getKey())) {
                                android.util.Log.d("testing", entry.getKey());
                                String buildingName = jsonBuilding.getString(entry.getKey());
                                JSONObject jsonCount = new JSONObject(buildingName);
                                int buildingCount = jsonCount.getInt("device_count");
                                android.util.Log.d("testing", "Building: " + buildingName + " Count: " + buildingCount);
                                WeightedLatLng buildingCoord = new WeightedLatLng(buildingList.get(entry.getKey()), buildingCount);
                                coordList.add(buildingCoord);
                            }
                        }
                        //mProvider = new HeatmapTileProvider.Builder().weightedData(coordList).maxIntensity(400).opacity(0.75).build();
                        heatmap.setWeightedData(coordList);
                        heatmap.setRadius(125);
                        mOverlay = mMap.addTileOverlay(new TileOverlayOptions()
                                .tileProvider(heatmap));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        android.util.Log.d("testing_error", "Error " + e.toString());
                    }
                }
            });
        }

    }

    public void viewBuilding(Building building){
    }
}